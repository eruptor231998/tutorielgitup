function init(){
	var canvas = document.getElementById("mon_canvas");
	ctx = canvas.getContext('2d');
}
init()

ctx.fillRect(10, 10, 480, 480);
ctx.fillStyle = "rgb(255,0,0)";
ctx.fillRect(30, 30, 440, 440);

ctx.fillStyle = "rgb(255,255,255)";
ctx.fillRect(50, 50, 400, 400);

ctx.fillStyle = "rgb(0,0,0)";
ctx.fillRect(70, 70, 360, 360);

ctx.fillStyle = "rgb(255,0,0)";
ctx.fillRect(90, 90, 320, 320);

ctx.fillStyle = "rgb(255,255,255)";
ctx.fillRect(110, 110, 280, 280);

ctx.beginPath();
ctx.fillStyle = "rgb(0,0,0)";
ctx.arc(250,250,140,150, Math.PI*2, true);
ctx.fill();

ctx.fillStyle = "white"
ctx.font = "48px Times New Roman";
ctx.shadowOffsetX = 10;
ctx.shadowOffsetY =-10;
ctx.shadowBlur = 0;
ctx.shadowColor = "rgba(255, 0, 0, 0.5)"; 
ctx.fillText('DEJA VU', 150, 250);

var image = new Image();
image.src = 'bateau.png';
image.onload = function () { afficherImage(); }

function afficherImage() {
	ctx.drawImage(image, 200, 270, 100,100 );
}

function animate(){
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY =0;
ctx.beginPath();
ctx.fillStyle = "rgb(0,0,0)";
ctx.arc(250,250,140,150, Math.PI*2, true);
ctx.fill();
afficherImage();
}

function animate1(){
ctx.fillStyle = "white"
ctx.font = "48px Times New Roman";
ctx.shadowOffsetX = 10;
ctx.shadowOffsetY =-10;
ctx.shadowBlur = 0;
ctx.shadowColor = "rgba(255, 0, 0, 0.5)"; 
ctx.fillText('DEJA VU', 150, 250);

}

var jeu=setInterval(animate, 420)
var jeu1=setInterval(animate1,230)
