var elt=document.querySelector('#c1');
alert(elt.innerHTML);

function action1(evt) {
	var body=document.querySelector('.today');
	body.appendChild(document.createTextNode(evt.key));
}

function changeCouleur(numero){
	var couleurs=['red','blue','yellow','lightgreen','coral','grey'];
	// on tire une couleur au hasard
	var num=parseInt(Math.random()*couleurs.length);

	var elt=document.querySelector('#c'+numero);
	elt.style.backgroundColor=couleurs[num];
}

function action2(evt) {
	var numero=evt.target.parentNode.getAttribute('id')[1];
	changeCouleur(numero);
}

window.addEventListener('keypress', action1);
var c1=document.querySelector('#c1');
c1.addEventListener('click', action2);
var c2=document.querySelector('#c2');
c2.addEventListener('click', action2);
