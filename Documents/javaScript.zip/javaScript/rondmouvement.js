function init(){
	var canvas = document.getElementById('mon_canvas'); //mettre l'id du canvas
	if (canvas.getContext) {
		ctx = canvas.getContext('2d');
		console.log(ctx) //affiche les éléments du canvas
	}
	else{
		console.log("Message pour les navigateurs ne supportant pas encore canvas");
	}
}
init()


function rondAleat1(nb, taille,couleur){
for(i=0; i<nb; i++){
ctx.beginPath();
if (couleur=="jaune"){
ctx.fillStyle = "rgb(255,255,0)";
}
if (couleur=="rouge"){
ctx.fillStyle = "rgb(255,0,0)";}
ctx.arc(Math.floor(Math.random()*280)+10,Math.floor(Math.random()*280)+10,taille,100, Math.PI*2, true);
ctx.fill();

}
}

//rondAleat1(1,5,"jaune")
//rondAleat1(1,2,"rouge")

function bouger(){
ctx.clearRect(width+5,height+5, -20,-20);
ctx.beginPath();
ctx.fillStyle = "rgb(0,0,255)";
ctx.arc(width,height,10,100, Math.PI*2, true);
ctx.fill();	
if (width<285 && height<285){
width+=5;
height+=5;
}
}
width=15;
height=15;

function rondAleat(){
for(i=0; i<1; i++){
nbr=0
height=Math.floor(Math.random()*280)+10;
width=Math.floor(Math.random()*280)+10;
for (j=1; j<=liste.length; j++){
if (liste[j-1]!=width && liste[j]!=height){
nbr+=1;
}
if (nbr==liste.length){
liste.push(width);
liste.push(height);
ctx.beginPath();
ctx.fillStyle = "rgb(255,0,0)";
ctx.arc(height,width,5,100, Math.PI*2, true);
ctx.fill();

}
}
}
}
var liste=[1,1];
//window.setInterval(rondAleat,1000);

function touche(){
	for (i=3; i<=liste.length; i++){
	if (event.clientY==liste[i-1] && event.clientX==liste[i]){
		console.log("ok");
	}
	}
	
}
onkeypress = function(e){
    if(e.charCode == 97){ //code ascii
       rondAleat();
    }
}

var btn = document.createElement("BUTTON");        // Créer un élément <button>
var t = document.createTextNode("CLICK ME");       // Créer un noeud textuel
btn.appendChild(t);                                // Ajouter le texte au bouton
document.body.appendChild(btn); 

btn.addEventListener("click", rondAleat);
//mon_canvas.addEventListener("click",rondAleat);



var btn = document.createElement("BUTTON");                                      
document.body.appendChild(btn);   
btn.innerHTML = "CLICK ME";                
btn.addEventListener("click", function() {
    alert("You just clicked me!");
});
 
var button = document.createElement("BUTTON");                                  
document.body.appendChild(button);  
button.innerHTML = "Clique";                
button.addEventListener("click", function() {
    alert("You just clicked me!");
    document.body.removeChild(btn);                        
});
 
button.style.position = "absolute";
btn.style.position = "absolute";
button.style.top = "400px";
btn.style.top = "400px";
button.style.left = "10px";
btn.style.left = "70px";